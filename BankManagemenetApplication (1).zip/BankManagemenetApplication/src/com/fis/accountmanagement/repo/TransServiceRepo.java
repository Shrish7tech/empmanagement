package com.fis.accountmanagement.repo;

import java.util.ArrayList;

import com.fis.accountmanagement.beans.Transactions;

public interface TransServiceRepo {
	
	public abstract String addTransactionNEFT(long transFromAcc, long neftAccNo, Transactions transaction);
	
	public abstract ArrayList<String> getTransForAccNo(Transactions transaction, long showTransAccNo);

}

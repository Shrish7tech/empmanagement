package com.fis.accountmanagement.service;

import com.fis.accountmanagement.beans.Accounts;
import com.fis.accountmanagement.exceptions.AccountNotFound;
//import com.fis.accountmanagement.exceptions.NotEnoughBalance;
import com.fis.accountmanagement.exceptions.NotEnoughBalance;

public interface AccountClientService {
	public abstract String addAccount(Accounts account);

	public abstract Accounts getAccount(long getAcc) throws AccountNotFound;
	
	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;

	public abstract void depositIntoBalance(long getAcc, double depositAmount);
	
//	public abstract Accounts getBalance(double getAccBalance) throws NotEnoughBalance;
}
